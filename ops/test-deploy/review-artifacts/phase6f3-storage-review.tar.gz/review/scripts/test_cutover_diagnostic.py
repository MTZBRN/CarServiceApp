"""Read-only fixed metadata for cutover review; no configuration or customer reads."""
import json
import os
from pathlib import Path
import stat
import subprocess


def run(*args):
    return subprocess.run(args, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, timeout=30, check=True,
        env={'PATH':'/usr/sbin:/usr/bin:/sbin:/bin','HOME':'/root','LC_ALL':'C'}).stdout.decode().strip()


def main():
    try:
        if os.geteuid()!=0:
            raise ValueError('root-required')
        if any(os.environ.get(k) for k in ('DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH')):
            raise ValueError('daemon-override')
        if os.path.lexists('/etc/carservice-test-deploy/actions-enabled'):
            raise ValueError('activation-present')
        rows=[]
        for name in ('/','/srv','/etc','/var','/var/lib','/opt','/opt/carserviceapp',
                     '/srv/carserviceapp-test','/etc/carservice-test-deploy','/var/lib/carservice-test-deploy'):
            p=Path(name)
            # Never follow a symlink, including an ancestor, for disk metadata.
            parents=(*reversed(p.parents),p)
            if any(q.is_symlink() for q in parents):
                rows.append({'path':name,'linked':True}); continue
            try:
                s=p.lstat()
            except FileNotFoundError:
                rows.append({'path':name,'absent':True}); continue
            row={'path':name,'uid':s.st_uid,'gid':s.st_gid,'mode':format(stat.S_IMODE(s.st_mode),'04o')}
            if stat.S_ISDIR(s.st_mode):
                v=os.statvfs(p)
                row.update(device=s.st_dev,available_bytes=v.f_bavail*v.f_frsize)
            rows.append(row)
        ids=run('docker','ps','-aq','--no-trunc','--filter','label=com.docker.compose.project=carserviceapp-test').splitlines()
        services=[]
        for cid in ids:
            fields='[{{json .Id}},{{json .Image}},{{json .State.Status}},{{json .State.Health.Status}},{{json .Mounts}},{{json .NetworkSettings.Networks}},{{json .HostConfig.PortBindings}},{{json (index .Config.Labels "com.docker.compose.project")}},{{json (index .Config.Labels "com.docker.compose.service")}}]'
            row=json.loads(run('docker','inspect','-f',fields,cid))
            if row[7]!='carserviceapp-test': raise ValueError('project-changed')
            services.append(row)
        network=json.loads(run('docker','network','inspect','-f','[{{json .Id}},{{json .IPAM.Config}},{{json .Labels}}]','carserviceapp-test_workshop'))
        print(json.dumps({'status':'REVIEW_REQUIRED','scope':'metadata-only','paths':rows,
            'test_services':services,'network':network,'compose_version':run('docker','compose','version','--short'),
            'activation_absent':True,'source_custody_verified':False,'disk_budget_verified':False,
            'native_model_verified':False,'migration_authorized':False}))
        return 0
    except Exception as e:
        # No exception text or raw CLI output, even when malformed metadata fails.
        print(json.dumps({'status':'STOP','stage':'cutover-metadata','error_type':type(e).__name__}))
        return 1


if __name__=='__main__':
    raise SystemExit(main())
