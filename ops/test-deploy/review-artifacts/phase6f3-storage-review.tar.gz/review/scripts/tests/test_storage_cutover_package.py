import hashlib
from contextlib import closing
import importlib.util
import json
import shutil
import shlex
from pathlib import Path
import sqlite3
import subprocess
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[2]


def load(name, path):
    spec=importlib.util.spec_from_file_location(name,ROOT/path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


builder=load('storage_builder','scripts/build_storage_package.py')
cutover=load('storage_cutover_fixture','ops/test-deploy/rehearsal/storage_cutover.py')
diagnostic=load('cutover_metadata','scripts/test_cutover_diagnostic.py')


class CutoverPackageTests(unittest.TestCase):
    @unittest.skipUnless(shutil.which('powershell') or shutil.which('pwsh'),'PowerShell required')
    def test_operator_entrypoint_uses_tty_no_stdin_and_propagates_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp)
            script=folder/'check.ps1'
            target=str(ROOT/'ops/test-deploy/CHECK_CUTOVER.ps1').replace("'","''")
            script.write_text("""
$env:PSModulePath=Join-Path $PSHOME 'Modules'
$global:record=$null
function ssh {
    $global:record=@{arguments=@($args);stdinCount=@($input).Count}
    $global:LASTEXITCODE=1
}
$failed=$false
try { & 'TARGET' -GitHubGateConfirmedDisabled } catch { $failed=$true }
@{failed=$failed;call=$global:record} | ConvertTo-Json -Depth 6 -Compress |
    Set-Content -Encoding UTF8 "$PSScriptRoot/result.json"
""".replace('TARGET',target),encoding='utf-8')
            result=subprocess.run([shutil.which('powershell') or shutil.which('pwsh'),
                '-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',str(script)],capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            value=json.loads((folder/'result.json').read_text(encoding='utf-8-sig'))
            self.assertTrue(value['failed'])
            self.assertEqual(value['call']['stdinCount'],0)
            self.assertEqual(value['call']['arguments'][:4],['-tt','-o','BatchMode=yes','gta-test'])
            tokens=shlex.split(value['call']['arguments'][4])
            self.assertEqual(tokens[:7],['sudo','-k','--','/usr/bin/python3','-I','-B','-c'])

    def test_package_is_repeatable_allowlisted_and_hash_verified(self):
        with tempfile.TemporaryDirectory() as tmp:
            a=builder.package(Path(tmp)/'a'); b=builder.package(Path(tmp)/'b')
            self.assertEqual(a['sha256'],b['sha256'])
            self.assertEqual(a['linux_rehearsal'],'NOT EXECUTED')
            with tarfile.open(a['archive']) as archive:
                members=archive.getmembers()
                self.assertTrue(all(m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts for m in members))
                contents={m.name:archive.extractfile(m).read() for m in members}
            checks={name:digest for digest,name in (line.split('  ',1) for line in contents['SHA256SUMS'].decode().splitlines())}
            self.assertEqual(set(checks),set(contents)-{'SHA256SUMS'})
            for name,digest in checks.items():
                self.assertEqual(hashlib.sha256(contents[name]).hexdigest(),digest)
            for manifest in ('INSTALL_ARTIFACTS.sha256','CUTOVER_DIAGNOSTIC.sha256'):
                for line in contents['review/ops/test-deploy/'+manifest].decode().splitlines():
                    digest,name=line.split('  ',1)
                    self.assertEqual(hashlib.sha256(contents['review/'+name]).hexdigest(),digest)
            self.assertFalse(any(Path(name).name.startswith('.env') or '/.git/' in name for name in contents))
            self.assertNotIn(b'compose_compat',contents['Dockerfile'])
            self.assertFalse(json.loads(contents['PROVENANCE.json'])['operator_approved'])
            with self.assertRaises(ValueError): builder.package(Path(tmp)/'a')

    def test_no_fixture_operation_before_disposable_boundary(self):
        with patch.object(cutover.h,'boundary',side_effect=RuntimeError('not disposable')), \
             patch.object(cutover.h,'real_run') as command:
            with self.assertRaisesRegex(RuntimeError,'not disposable'): cutover.run('success')
            command.assert_not_called()

    def test_pair_comparison_detects_actual_database_and_upload_changes(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); data=root/'data'; uploads=root/'uploads';data.mkdir();uploads.mkdir()
            with closing(sqlite3.connect(data/'app.db')) as db, db:
                db.executescript('CREATE TABLE Customers(Id INTEGER); CREATE TABLE __EFMigrationsHistory(MigrationId TEXT);')
            (uploads/'fictional.txt').write_text('FICTIONAL')
            initial=cutover.pair_state(data,uploads)
            (uploads/'fictional.txt').write_text('CHANGED')
            self.assertNotEqual(initial,cutover.pair_state(data,uploads))
            (uploads/'fictional.txt').write_text('FICTIONAL')
            with closing(sqlite3.connect(data/'app.db')) as db, db: db.execute('INSERT INTO Customers VALUES(1)')
            self.assertNotEqual(initial,cutover.pair_state(data,uploads))

    def test_native_validator_is_not_adapter_or_mock(self):
        source=(ROOT/'ops/test-deploy/rehearsal/storage_cutover.py').read_text()
        self.assertIn("d.validate_model(model, 'baseline')",source)
        self.assertNotIn('unittest.mock',source)
        self.assertNotIn('compose_compat',source)
        self.assertIn('os.kill(os.getpid(), signal.SIGKILL)',source)
        self.assertIn("h.require(prod()==before_prod",source)

    def test_metadata_gate_prevents_any_docker_call(self):
        with patch.object(diagnostic.os,'geteuid',return_value=0,create=True), \
             patch.dict(diagnostic.os.environ,{},clear=True), \
             patch.object(diagnostic.os.path,'lexists',return_value=True), \
             patch.object(diagnostic,'run') as command:
            self.assertEqual(diagnostic.main(),1)
            command.assert_not_called()

    def test_diagnostic_has_no_file_content_or_mutation_calls(self):
        import ast
        tree=ast.parse((ROOT/'scripts/test_cutover_diagnostic.py').read_text())
        for node in ast.walk(tree):
            if isinstance(node,ast.Call):
                self.assertNotIn(getattr(node.func,'attr',getattr(node.func,'id','')),
                    {'open','read_bytes','read_text','write_text','write_bytes','chmod','chown','unlink','mkdir'})

    def test_diagnostic_manifest_matches(self):
        text=(ROOT/'ops/test-deploy/CUTOVER_DIAGNOSTIC.sha256').read_text().strip()
        digest,name=text.split('  ',1)
        self.assertEqual(name,'scripts/test_cutover_diagnostic.py')
        self.assertEqual(digest,hashlib.sha256((ROOT/name).read_bytes()).hexdigest())

    def test_launcher_preserves_boundary_and_explicit_approval(self):
        script=(ROOT/'ops/test-deploy/rehearsal/run-storage-rehearsal.sh').read_text()
        for expected in ('--approve-disposable-host','--approve-fictional-recovery',
                         '--network none --cgroupns private',"== '[]'",'sha256sum --check SHA256SUMS'):
            self.assertIn(expected,script)
        self.assertNotIn('docker system prune',script)
        self.assertNotIn('-v /',script)
