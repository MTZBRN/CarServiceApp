"""Create a NEW allowlisted source package; never include local data or credentials."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'ops/test-deploy/rehearsal'))
from prepare_context import FILES

EXTRA=(
    'ops/test-deploy/rehearsal/storage_cutover.py',
    'ops/test-deploy/rehearsal/Dockerfile.storage',
    'ops/test-deploy/rehearsal/run-storage-rehearsal.sh',
    'ops/test-deploy/MIGRATE_TEST_STORAGE.md', 'ops/test-deploy/STORAGE_REHEARSAL_HANDOFF.md',
    'ops/test-deploy/README.md','ops/test-deploy/BOOTSTRAP.md',
    'ops/test-deploy/INSTALL_ARTIFACTS.sha256',
    'ops/test-deploy/CHECK_CUTOVER.ps1','ops/test-deploy/CUTOVER_DIAGNOSTIC.sha256',
    'scripts/test_cutover_diagnostic.py','scripts/test_compose_native.py','scripts/diagnose_native_paths.py',
    'scripts/test_storage_plan.py','scripts/build_storage_package.py',
    'scripts/tests/test_storage_cutover_package.py',
)


def package(destination):
    destination=destination.absolute()
    if destination.exists(): raise ValueError('new output directory required')
    contents={}
    for name in sorted(set(FILES+EXTRA)):
        p=ROOT/name
        if any(q.is_symlink() for q in (p,*p.parents)) or not p.is_file() or not p.resolve().is_relative_to(ROOT.resolve()):
            raise ValueError('missing or linked allowlisted input')
        contents['review/'+name]=p.read_bytes().replace(b'\r\n',b'\n')
    contents['Dockerfile']=contents['review/ops/test-deploy/rehearsal/Dockerfile.storage']
    contents['run-storage-rehearsal.sh']=contents['review/ops/test-deploy/rehearsal/run-storage-rehearsal.sh']
    base=subprocess.run(['git','rev-parse','HEAD'],cwd=ROOT,check=True,capture_output=True,text=True).stdout.strip()
    contents['PROVENANCE.json']=(json.dumps({'base_commit':base,'source':'uncommitted-working-tree-snapshot',
        'linux_rehearsal':'NOT EXECUTED','operator_approved':False},sort_keys=True)+'\n').encode()
    contents['SHA256SUMS']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(contents.items())).encode()
    destination.mkdir(parents=True)
    archive=destination/'phase6f3-storage-review.tar.gz'
    with archive.open('xb') as output, gzip.GzipFile(fileobj=output,mode='wb',mtime=0,filename='') as compressed, tarfile.open(fileobj=compressed,mode='w') as tar:
        for name,data in sorted(contents.items()):
            info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644; info.mtime=0
            tar.addfile(info,io.BytesIO(data))
    digest=hashlib.sha256(archive.read_bytes()).hexdigest()
    (destination/'SHA256SUMS').write_text(digest+'  '+archive.name+'\n',encoding='ascii')
    return {'archive':str(archive),'sha256':digest,'files':len(contents),'linux_rehearsal':'NOT EXECUTED'}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    print(json.dumps(package(p.parse_args().output),indent=2))
