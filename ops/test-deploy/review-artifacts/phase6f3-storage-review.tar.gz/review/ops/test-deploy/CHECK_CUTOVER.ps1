param([switch]$GitHubGateConfirmedDisabled)
$ErrorActionPreference = 'Stop'
if (-not $GitHubGateConfirmedDisabled) { throw 'Confirm TEST_DEPLOY_ENABLED is absent/false first.' }
$repo = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$file = Join-Path $repo 'scripts/test_cutover_diagnostic.py'
$manifest = [IO.File]::ReadAllLines((Join-Path $PSScriptRoot 'CUTOVER_DIAGNOSTIC.sha256'))
if ($manifest.Length -ne 1) { throw 'Unexpected diagnostic manifest.' }
$parts = $manifest[0] -split '  ',2
if ($parts[1] -ne 'scripts/test_cutover_diagnostic.py' -or
    (Get-FileHash -Algorithm SHA256 -LiteralPath $file).Hash.ToLowerInvariant() -ne $parts[0]) { throw 'Diagnostic hash mismatch.' }
$encoded = [Convert]::ToBase64String([IO.File]::ReadAllBytes($file))
$expression = "exec(__import__('base64').b64decode('$encoded'))" -replace "([()'])", '\$1'
$command = "sudo -k -- /usr/bin/python3 -I -B -c $expression"
if ($command.Length -gt 28000) { throw 'Command too long.' }
# Interactive sudo only; no script or password is piped through stdin.
ssh -tt -o BatchMode=yes gta-test $command
if ($LASTEXITCODE -ne 0) { throw 'Metadata check stopped. Do not migrate or install.' }
