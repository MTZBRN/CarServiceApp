# Phase 6F.3 — dedicated TEST storage preparation

Status: **prepared locally; NOT authorized for execution**. This supersedes the
existing-VPS installation instructions in INSTALL_EXISTING_TEST.md and the
configuration-only proposal in ROOT_PATH_DESIGN.md. No VPS commands were run.
Do not run the old RESUME_NATIVE_CHECK.ps1 against the old staged artifact set:
helper/template hashes have changed deliberately. Do not overwrite that staging
tree to make verification pass. Review and stage this complete new bundle under
`/root/carservice-test-migrate-6f3/review` only after separate staging approval.
The supplied manifest describes uncommitted local bytes, not a reviewed Git commit.
Record the final reviewed commit and independently verified artifact hashes before
any installation. No automatic migration executor is supplied.

For the transferable native-only Linux harness, expected failure/recovery results,
byte manifests and optional read-only VPS metadata entry point, see
[STORAGE_REHEARSAL_HANDOFF.md](STORAGE_REHEARSAL_HANDOFF.md). Linux execution remains
NOT EXECUTED; the previous deployment rehearsal adapter cannot establish native
compatibility for this storage migration.

## Layout and ownership contract

| Path | Owner / mode | Purpose |
|---|---|---|
| `/srv/carserviceapp-test` | root:root 0700 | TEST-only trusted namespace; all ancestors root-owned, no links or group/other write |
| `data`, `uploads` beneath it | 1654:1654 0700 directories, 0600 regular files | Existing application storage format; DB is `data/app.db` |
| `backups` beneath it | root:root 0700; artifacts 0600 | New paired backups; existing legacy backups retained untouched |
| `/etc/carservice-test-deploy` | root:root 0711 | Existing restricted-SSH gate needs traversal; all contents private unless explicitly executable |
| `environment` beneath it | root:root 0600 | Reviewed JWT values and confirmed network interpolation inputs; no reference to live `.env.test` |
| `docker-compose.test.yml` beneath it | root:root 0600 | Standalone future runtime template, new storage binds |
| `baseline/compose.json` beneath it | root:root 0600; baseline dir 0700 | Reviewed, self-contained, same-revision cutover baseline with exact existing image IDs; approval input, never executed by deployment helper |
| `/var/lib/carservice-test-deploy` and `home`, `source.git` | root:root 0700 | Isolated mirror, journals, locks; no worktree reuse |

Do not change `/opt/carserviceapp`, its worktree, environment, storage or backup
permissions. Do not use symlinks or bind-mount aliases from the new hierarchy to
the old one. The existing alias/submount rejection remains. A separate filesystem
mounted beneath these paths would require a separate isolation design; do not
relax mount checks to fit one. Inspect `/srv` ownership, filesystem and free space
before creating anything; never repair an unexpected ancestor automatically.

The application sees the same `/app/data` and `/app/uploads` destinations. Docker
resolves host bind sources as root; container UID 1654 accesses the mounted leaves,
not the root-private host parent. Verify this with the actual images in a disposable
Linux test before scheduling migration. Frontend storage and UID remain unchanged.

## Existing evidence and required refresh

Reported existing revision: `8b6b7ad` (short, full revision not yet established).
Project `carserviceapp-test`, network `carserviceapp-test_workshop`, subnet
`172.30.91.0/24`, backend `172.30.91.2`, frontend `172.30.91.3`, frontend published
only on `127.0.0.1:5174` to container 8080. Existing backend host binds are expected
at `/opt/carserviceapp/test-data` and `test-uploads`; service storage owner is
1654:1654. Parent is 1000:1000 0750; live env is 0:0 0600. Native Compose is reported
5.7.0, Engine 29.9.2, Python 3.12.3; gh is missing. Both activation gates are disabled.
Exact current container/image IDs, mount records, full revision, network ID/gateway,
disk budgets and source sizes must be refreshed. No inventory of customer contents
has been collected by this work. TEST and PROD share the host and daemon.

At separately approved metadata review, use only selected fields, for example:

```sh
docker ps -aq --no-trunc --filter label=com.docker.compose.project=carserviceapp-test
# For each verified TEST ID, substitute the exact ID, never an unfiltered inspect:
docker inspect --format '{{.Id}} {{.Image}} {{.State.Status}} {{.State.Health.Status}} {{json .Mounts}} {{json .NetworkSettings.Networks}} {{json .HostConfig.PortBindings}}' REVIEWED_TEST_ID
docker network inspect --format '{{.Id}} {{json .IPAM.Config}} {{json .Labels}}' carserviceapp-test_workshop
```

Stop for extra TEST services, wrong project labels, shared writers/storage/network,
unexpected mounts, public publishing or changed IDs. Never print Config.Env, logs,
database rows, upload names or secret values. Preflight's existing cross-project
metadata isolation check is required; it never reads PROD files or changes PROD.
Coordinate a host-wide administrative change freeze during the maintenance window;
do not disable shared host services or change PROD as a shortcut.

## Gate A — local/disposable review, no VPS mutation

Run locally from the new reviewed tree:

```powershell
& 'C:\CarServiceApp\.stage4a-tools\python314\python.exe' 'C:\CarServiceApp\native-compose-diagnostics\scripts\test_storage_plan.py' --dry-run
```

This validates paths and the proposed Compose model using fictional values and the
real validators. It does not inspect the VPS, invoke Docker or authorize migration.
Run all Python tests and all three disposable Linux rehearsal scenarios with
explicit fixture recovery approval. Retain new Linux results: earlier results for
the old paths do not validate this change. Then test the actual application images,
UID access and same-schema restart on fictional data. The fixture schema is not EF.

Before Gate B, record operator approval of exact source SHA/artifact hashes, staged
destinations, same-revision image pair, source-custody plan, planned downtime,
backup capacity, rollback conditions and named operator. No approval JSON or
deployment gate is created. If any item is unknown, NO-GO.

## Gate B — separately authorized inactive staging and native compatibility

This stage is **not executed or currently authorized**. Use fresh, individually
verified root-owned destinations only; stop on any collision, symlink, writable
ancestor or failed checksum. Retain the previous staging tree for provenance.
Prepare root-private reviewed environment and baseline files; do not execute a
live worktree Compose file to derive them. Review the effective TEST configuration
and compare relevant values privately with the running TEST configuration. Treat
the legacy ancestor as mutable: root ownership of its leaf is not enough. Require
exclusive administrative custody of source configuration during capture/review,
with before/after identity and digest checks. No unattended copy from an untrusted
source, shell sourcing of dotenv, or secret output is allowed. If that custody
cannot be established without additional host changes, STOP for separate approval.

The new runtime environment contains the unchanged JWT settings plus the three
verified network values; the old `.env.test` stays byte-for-byte unchanged. No
values may be guessed or printed. Prepare two standalone configurations:

* Future runtime template from this bundle, with new binds and existing network.
* `baseline/compose.json`: reviewed same-revision configuration for cutover, exact
  existing backend/frontend image IDs, no build/extends/env_file/include, same
  network/ports/hardening/healthchecks and only the two changed host bind sources.
  Preserve a separate root-private old-path recovery baseline and unchanged env
  outside the runtime directory. Neither baseline should contain embedded secrets.

Use the **native VPS** Compose installation, never the rehearsal adapter. The new
diagnostic can validate the candidate without starting services, after its trusted
paths and environment have been staged with separate authorization:

```sh
sudo -k -- /usr/bin/python3 -I -B /root/carservice-test-migrate-6f3/review/scripts/test_compose_native.py check --compose /root/carservice-test-migrate-6f3/review/ops/test-deploy/docker-compose.test.yml --env-file /etc/carservice-test-deploy/environment --project-directory /root/carservice-test-migrate-6f3/home
```

All ancestors and candidate files must pass trust checks. `config` output/stderr
stays captured; return only sanitized status. Separately validate the exact
same-revision cutover and recovery baselines with native Compose in root-private
output files and review normalized models/images before accepting them. Do not
normalize away rejected options or expand the production allowlist. Native refusal
means STOP, no installation/cutover. Verify disk reserves for legacy source, paired
backup, restored verification copy and new copy simultaneously, plus the helper's
existing aggregate reserves. Do not reclaim Docker cache or legacy backups here.

Only after native compatibility and Gate B checks pass may a separately approved
inactive install place the reviewed helper/preflight/storage/SSH-gate artifacts in
their normal root-owned destinations, install verified gh without changing shared
Docker, and prepare the isolated read-only mirror. No live SSH/sudo activation.
Installed preflight is expected to refuse old live mounts before cutover; never
change it to accept both layouts. Do not claim installation readiness yet.

## Gate C — explicit maintenance/migration approval and downtime start

No command below is authorized by this preparation. Operator must explicitly
approve **storage migration only, same images, no application release**, with a
maintenance window and recovery operator available. Confirm both gates disabled,
no approved.json, no competing automation, two exact TEST IDs/images unchanged,
source identity and isolation, trusted destinations and available capacity.

1. Close TEST ingress using a separately reviewed TEST-only method. Do not edit
   shared proxy/PROD routes. Exclude background jobs, clients and external writers.
2. Stop only the recorded frontend ID, then backend ID, and verify both exited.
   Do not use `compose down`, delete networks, or stop containers by broad filters.
   Downtime begins here. Record health/image/mount metadata privately.
3. Establish exclusive custody of legacy TEST source entries while capturing the
   pair. UID 1000 can rename these entries even with root-owned children. Coordinate
   administrative sessions and jobs, verify unchanged directory/device/inode/link
   metadata and absence of links/hardlinks/aliases before and after capture. A
   one-time check alone is not a defense against an active mutator. Abort if custody
   is uncertain; do not change the shared parent permissions.
4. Create a paired backup using the reviewed `ops_storage.backup` implementation
   into a fresh root-private migration backup directory. Never copy only app.db or
   discard WAL. The reviewed Python API call is:

   ```python
   pair = storage.backup(Path('/opt/carserviceapp/test-data/app.db'),
                         Path('/opt/carserviceapp/test-uploads'),
                         Path('/srv/carserviceapp-test/backups'), quiesced=True)
   ```

   Run only with verified stopped writers and custody; store the returned path in
   the root-private migration record, not public logs. Backup uses SQLite backup,
   includes committed WAL, checks integrity/foreign keys, upload hashes and source
   stability. Source SQLite access may create sidecars; this belongs to the later
   explicit migration authorization, not today's read-only preparation.
5. Run `storage.restore_test(pair, scratch, max_upload_bytes=reviewed_bound)` into a
   **new** `carserviceapp-restore-test-*` child of a fresh root-private directory
   under `/var/tmp`. Default limit is 1 GiB; review real requirements before changing
   the bound. Verify checksum inventory, full DB integrity, foreign keys, migration
   history, table counts and every upload digest. Keep detailed results private.
6. Only after restore verification, materialize **new absent** `data` and `uploads`
   directories from the verified restored pair, using exclusive creation, no links,
   no merge or overwrite and no raw tar extraction. Set ownership only in the new
   leaves to 1654:1654, dirs 0700/files 0600. Never apply recursive ownership changes
   to `/srv`, `/opt`, or an existing path. Copying/publishing procedure must verify
   actual resolved destinations and same-filesystem assumptions; do not move a
   scratch directory across filesystems and assume atomicity. On partial failure,
   keep new files quarantined, do not silently retry into them.
7. Recheck copied DB integrity, exact complete migration list, table counts and
   upload inventory against the verified pair. Confirm no copied SQLite WAL/SHM
   accompanies the restored standalone DB. Preserve the pair and old source intact.

The above are the reviewed operation sequence and API primitives, not a turnkey
live migration script. Before Gate C, the operator must review a concrete execution
sheet populated with exact IDs, scratch paths, byte bounds and baseline hashes.
Missing values cannot be filled safely from the current evidence.

## Gate D — same-revision cutover, then installed preflight

Keep TEST ingress closed. Obtain explicit operator approval to recreate only the
two TEST containers with the reviewed baseline. Verify current existing image IDs
still match, native normalized baseline matches exactly, no build/pull is required,
and network identity is unchanged. Start backend first with no dependencies,
`--no-build --pull never --wait`; then frontend. Do not build or promote a revision.
The exact image IDs avoid tag drift. Starting the existing backend can run EF
startup code: require known matching migration history beforehand and stop if it
changes. Same-image startup must not be assumed to prove no schema writes.

Reinspect actual IDs/images/binds, IPs, ports, network ID, health, DB integrity,
schema history, business counts and upload inventory. Run smoke and authorized
fictional test-user checks while ingress is isolated. Document any deliberate
validation writes and distinguish them from migration corruption.
Run `/usr/local/sbin/carservice-test-preflight` with interactive sudo. It must pass
with new storage paths, root-controlled configuration, verified gh/mirror and
existing strict isolation/space checks. No fallback to old paths, no fixture adapter.
Compare PROD container IDs/images/state and network metadata to the private baseline
without accessing their data; investigate changes, never issue compensating PROD
commands. No shared resource changes are part of cutover.

Before reopening TEST, operator accepts the new storage as authoritative and records
the write boundary time. Downtime ends only after that approval. Keep old source,
backups and both recovery baselines protected and retained; no deletion/retention
job or automation activation is included. Refresh the paired backup after acceptance
under a separate quiesced backup window, not while writers are active.

## Rollback / failure boundaries

* Before stopping TEST: abandon inactive staging; services remain unchanged.
* After stopping, before recreation/new writes: if custody/integrity of old source
  remains verified, separately approve restarting the recorded old TEST IDs. If
  containers were replaced, use the privately reviewed old-path baseline with exact
  old image IDs. Never execute the mutable legacy worktree configuration as root.
* After new startup but before traffic: first stop new TEST writers and determine
  whether startup/validation wrote anything. Old-source rollback is allowed only
  after explicit acceptance that no required writes would be lost and old schema
  and sources remain valid. A healthcheck alone cannot establish this.
* After reopening or any required new write: the new pair is authoritative. Do not
  restart old data. Quiesce TEST, take and verify a new pair, retain failure evidence,
  and approve a forward repair or a separately designed reverse migration. No
  automatic overwrite, restore or database downgrade is supplied.
* On partial copy, failed checks, changed IDs or network: remain in maintenance and
  stop at that gate. Keep private evidence and all backups. Do not clear a deployment
  in-progress marker to force a retry; investigate any unexpected marker separately.

## Approval contract and final go/no-go

The installed helper and installed preflight load the same constants. Compose,
live mount checks, DB access, backup output and recovery journals all use the new
paths. `compose_sha256` now binds the root-controlled `baseline/compose.json`, not
the legacy worktree file. `env_sha256` binds the actual new `environment`, and
`frozen_compose_sha256` binds the runtime template. Every future release approval
must include `"storage_layout": "test-root-v1"`; missing/old layout is rejected.
All prior approvals are invalid. Create none during migration. Any baseline/env/
frozen-file change requires fresh review/hashes. The former worktree is never read
by the deployment helper. Runtime backup/restore verification algorithm is unchanged;
no automatic failure recovery is added.

GO for future inactive readiness requires all of: new Linux rehearsal evidence;
native Compose PASS; reviewed exact artifact versions; exclusive source custody;
paired backup AND full restored/copy validation; same-image accepted cutover; trusted
ancestors; new exact live mounts; unchanged TEST network/ports; no shared PROD mounts;
installed preflight PASS; recovery plan accepted; TEST acceptance complete; both
deployment gates still disabled. Otherwise NO-GO. Gate C and Gate D require explicit
operator approvals even if all preceding checks pass. Future automated deployment,
SSH activation and release approval are separate actions, never inferred here.

## Local validation record

109 Python tests ran: 107 passed, two platform-specific skips. Coverage includes
new/legacy model and live bind paths, private-leaf/untrusted-ancestor refusal,
missing/old layout approval, changes to each of the three configuration hashes,
offline dry-run refusal of legacy layout, and existing synthetic deployment,
backup-failure and migration-failure recovery paths. The offline layout dry-run
returned PASS with `migration_authorized: false`; `git diff --check` passed.
Docker is unavailable locally and WSL reports not installed. These tests do not
constitute a Linux container rehearsal, actual EF migration test, native Compose
compatibility result, or permission to execute migration. All Gate A–D evidence
and operator approvals remain necessary. No VPS commands were executed.
