# Transferable Phase 6F.3 review package

**Linux/Docker rehearsal: NOT EXECUTED. Real VPS migration: NOT AUTHORIZED.**
No separate disposable host is currently available. Windows has neither Docker nor
Podman, and WSL reports not installed. The user explicitly prohibits using the
shared TEST/PROD VPS for rehearsal. No workflow was dispatched, no code committed
or pushed, and no real VPS connection was made. This package is a candidate for
review, not a successfully rehearsed migration release.

## Contents and exact trust evidence

`scripts/build_storage_package.py` packages only an explicit source allowlist.
It excludes `.git`, environment files, local data, credentials and existing backup
directories. It normalizes source line endings to LF and emits a deterministic
tar.gz, an outer SHA256SUMS, an inner SHA256SUMS for every source and entry point,
and PROVENANCE.json identifying the base commit and uncommitted snapshot status.
The hashes establish exact bytes, **not independent approval**. Operator review and
acceptance of these bytes is a separate gate. Do not substitute the old Phase 6F.2
manifest or copy old staged helpers over this package.

Base-image tags and package repositories remain upstream build inputs, not pinned
by the source manifest. The launcher records resulting image IDs/digests and Docker
version in evidence. Review these with the native Compose version; a source hash
alone does not make two image builds identical.

The new native-only Dockerfile installs the vendor Compose binary directly; no
Compose adapter is installed. It currently inherits the version from the existing
`docker:27.5.1-cli` build stage. The report records the actual native Compose version.
This is not proof of compatibility with the reported VPS Compose 5.7.0. If native
normalization adds keys rejected by `validate_model()`, the run must STOP before
provisioning services. Do not remove keys, substitute the rehearsal adapter or
claim the scenarios passed. A new plugin/version matrix requires separate review.

## Stage 1 — local package integrity, no VPS connection

From the worktree, build to a NEW destination:

```powershell
& 'C:\CarServiceApp\.stage4a-tools\python314\python.exe' scripts/build_storage_package.py --output test-results/phase6f3-review-package
Get-FileHash test-results/phase6f3-review-package/phase6f3-storage-review.tar.gz -Algorithm SHA256
```

Compare with the emitted outer SHA256SUMS and the reviewed handoff hash. Retain
the archive, manifest and provenance together. Existing output directories are
refused; no build silently overwrites evidence. Any source edit requires a new
package, new hashes and review. The archive itself contains all sources needed to
build the disposable harness; base images and OS packages are fetched on the
disposable host during image preparation. An air-gapped image bundle is not included.

## Stage 2 — dedicated disposable Linux/Docker host only

Prerequisites: a fresh disposable Linux VM with Docker Engine capable of privileged
DinD, cgroup v2, native CPU/memory/PIDs limits, Bash, Python 3.12+, tar, sha256sum and
sufficient space for four sequential VFS rehearsals. No credentials, agent forwarding,
existing workloads, cloud production roles, real data or mounted production disks.
Do not install anything on the shared VPS to obtain these prerequisites.
Network is used only for image/package build outside the isolated test box.

Transfer the archive and outer SHA256SUMS using your chosen approved mechanism.
In a fresh directory on that disposable VM:

```sh
sha256sum --check SHA256SUMS
mkdir phase6f3-review
tar -xzf phase6f3-storage-review.tar.gz -C phase6f3-review
cd phase6f3-review
sha256sum --check SHA256SUMS
python3 review/scripts/test_storage_plan.py --dry-run
bash run-storage-rehearsal.sh --approve-disposable-host --approve-fictional-recovery
```

Run the launcher with permission to use this VM's local Docker socket. Do not use
a remote Docker context. The launcher refuses non-Linux, remote context/env,
credential forwarding, existing containers and reused output. It uses a new
labelled outer box for each case with `--network none --cgroupns private`, no host
mounts and no host socket. Existing cgroup enforcement checks execute inside it.
The outer box is privileged solely for the dedicated nested daemon; this is not
safe to run on a shared/production host. No sysctl, permission, healthcheck or
isolation bypass is introduced. Cleanup targets only its labelled box, not images,
volumes or arbitrary resources on the host. Dispose of the whole VM afterward.

## Stage 3 — inspect actual results, do not infer PASS

Expected on a fully successful run: four native-compose PASS records and one final
PASS record per scenario in `evidence/*.jsonl`, plus the launcher final PASS. Every
scenario must complete from a fresh inner daemon. Evidence also contains private
synthetic daemon logs and reports copied before outer-container cleanup.

| Case | Actual operations / required evidence |
|---|---|
| success | Fictional legacy UID-1000 ancestor, real SQLite/uploads, stopped-writer backup, checksum-verified restore, new UID-1654 copy, healthy same-image recreation and exact new binds |
| before-cutover | Actual destination collision raises FileExistsError before either old container stops; IDs/images/state remain unchanged |
| interrupted-cutover | Separate worker recreates backend then receives real SIGKILL; durable stage is backend-started; explicit fictional recovery returns both services to old pair using identical image IDs |
| failed-startup | Same backend image rejects a fictional marker on the new bind; native Compose startup fails; explicit recovery recreates healthy old-pair services |

Every completed case compares original SQLite table counts/schema and every upload
digest, exact image IDs and healthy services. Success additionally uses the real
deployment live-mount/network validator. A separate **fictional PROD** container,
volume and isolated network are exercised in the inner daemon; its ID, image,
start time, running state, mount/network metadata and content digest must remain
identical. This verifies the fixture boundary, not the real VPS's PROD isolation.

The exact production template is first resolved with native Compose and fictional
values and passed unchanged to strict `validate_model()`. Only afterward is the
inner fixture network marked internal. Rejected native defaults are a genuine
compatibility blocker, not permission to silently normalize the model.

The fictional backend checks DB integrity and upload contents as UID 1654; it is
not the CarServiceShop/EF binary. Real-image startup/schema acceptance remains
required. These scenarios do not exercise every possible interruption point or
post-traffic reverse migration. The production runbook still forbids rolling back
to stale data after required writes. Do not run real rollback based on fixture PASS.

On any STOP/nonzero result: preserve evidence, do not skip the check, and do not run
later cases as though the failed one passed. Use a new extracted package/VM for a
reviewed rerun. Raw logs contain only synthetic fixture data but should still be
reviewed before sharing. Return sanitized stage, scenario, native version, key
names and error type; never substitute a real VPS config to investigate.

## Stage 4 — next safe real-VPS action: metadata only

Linux execution is still pending. The following optional command gathers read-only
readiness metadata; it does not authorize, install or execute migration. First
confirm GitHub `TEST_DEPLOY_ENABLED` remains absent/false. From normal interactive
Windows PowerShell in the reviewed worktree:

```powershell
& 'C:\CarServiceApp\native-compose-diagnostics\ops\test-deploy\CHECK_CUTOVER.ps1' -GitHubGateConfirmedDisabled
```

It verifies a local diagnostic SHA256, uses `ssh -tt` and fresh interactive sudo,
executes the reviewed source in memory, and writes no VPS file. No script/password
stdin, password variables or passwordless sudo are used. It checks the server
gate, reports selected TEST metadata, native version and filesystem free space.
It reads no environment contents, DB, uploads, backups, PROD contents or credentials.
REVIEW_REQUIRED is the expected successful result; it is never readiness PASS.
STOP means stop, not repair permissions. Return only its metadata JSON privately.
No separate install/stop/recreate command is currently approved.

## Live evidence and approval gates still outstanding

* Exclusive custody of UID-1000-controlled source entries throughout capture;
  legacy root-owned leaves do not remove parent replacement risk.
* Refreshed exact TEST IDs/images/full revision, effective binds, network ID/IPAM,
  published ports, health, other writers/aliases and shared-resource exclusion.
* Source pair size and aggregate capacity for backups, restored copy, new copy,
  scratch and Docker headroom. Free-space figures alone do not prove sufficiency.
* Trusted new ancestors and absent/collision-reviewed destinations; private captured
  configuration provenance; exact future native VPS Compose acceptance.
* Verified paired backup/full restored inventory and same-image real-app acceptance.
* Named operator, maintenance window, TEST ingress-only procedure, recovery criteria
  and concrete execution sheet populated with actual IDs/paths/bounds.
* Explicit approvals at each gate in MIGRATE_TEST_STORAGE.md, installed preflight
  after cutover, both deployment gates disabled, and no release approval or SSH
  activation. Source installation and migration remain separate later approvals.

Do not proceed with VPS cutover until all four Linux cases and native strict model
validation have passed and live evidence is reviewed. The user's definition of
done involving end-to-end Linux execution is **not met** by package construction.

## Local validation and change inventory

118 local Python tests: 116 passed, two platform-specific skips. Nine new package
tests cover deterministic archive construction, all manifest hashes, destination
collision refusal, disposable-boundary refusal before external operations, actual
fictional SQLite/upload change detection, native-only wiring, gate refusal,
metadata-only source, and the PowerShell TTY/no-stdin/failure path with mocked SSH.
Bash syntax validation and `git diff --check` passed. No test executed Docker/Linux
storage cutover or connected to SSH. Local tests do not satisfy the Linux gate.

Files added in this continuation:

* `ops/test-deploy/rehearsal/storage_cutover.py`
* `ops/test-deploy/rehearsal/Dockerfile.storage`
* `ops/test-deploy/rehearsal/run-storage-rehearsal.sh`
* `scripts/build_storage_package.py`
* `scripts/test_cutover_diagnostic.py`
* `scripts/tests/test_storage_cutover_package.py`
* `ops/test-deploy/CHECK_CUTOVER.ps1`
* `ops/test-deploy/CUTOVER_DIAGNOSTIC.sha256`
* `ops/test-deploy/STORAGE_REHEARSAL_HANDOFF.md`

Updated `ops/test-deploy/MIGRATE_TEST_STORAGE.md` with the native-only package
handoff. Other uncommitted Phase 6F.3 changes predate this continuation. No existing
workflow, production deployment helper or security validator was changed here.
