# Isolated TEST release

This release path is disabled at installation. The Actions dispatcher accepts one full commit SHA. The server has a separate root-owned approval for that SHA, the reviewed TEST configuration and the complete expected migration list. A feature CI pass is useful for review. Only the current tip of protected `test-deploy` is eligible, after Workshop CI succeeds on that exact branch push on GitHub-hosted runners.

## Promoting a candidate

Open a reviewed PR from the feature branch into `test-deploy`. For a selective promotion, cherry-pick onto a candidate based on `test-deploy` and open a PR from that candidate. Record maintainer review of the final changes, including conflict resolutions, in the PR. See the single-maintainer policy below; do not claim independent review. After the protected ref advances, obtain its full tip SHA and wait for the successful Workshop CI **push** run at that SHA. A merge, squash or cherry-pick can produce a new SHA; use that final object for server approval and dispatch. Promotion requires no application merge into main.

Dispatch with the workflow ref set to `test-deploy` and that SHA as the only input. Where the plan supports required reviewers, the maintainer approves the isolated-test environment request separately from the recorded PR review; root-owned server approval is always mandatory. If the branch advances during review or build, repeat CI, approval and dispatch for the new tip. Coordinate promotions during the short maintenance window after the final admission check.

GitHub requires the manual workflow file to exist on the repository default branch for workflow_dispatch registration. If it is absent, registration of the reviewed workflow definition is a separate bootstrap prerequisite. Application promotion and deployment use the test-deploy ref. [GitHub workflow_dispatch documentation](https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows#workflow_dispatch)

## First installation and rehearsal

For the existing VPS, follow [Phase 6F.3 migration gates](MIGRATE_TEST_STORAGE.md). The new helper intentionally refuses the old live mounts. Do not install or activate it as a substitute for migration.

1. Review and merge CI through the repository's normal approval process. The workflows belong in this repository's .github/workflows directory. Require Workshop CI / verify on protected test-deploy, PR-only updates, recorded maintainer review and review of workflows, Dockerfiles, migrations, scripts and this runbook. Disallow direct pushes, deletion, force-push and protection bypass. Review release workflows and deployment controls explicitly. With only one maintainer, require PRs and CI but set required approving reviews to zero and do not require an impossible self code-owner approval; do not use an admin bypass. Keep the CI verify job on GitHub-hosted runners. Keep TEST_DEPLOY_ENABLED unset. Run CI on GitHub and record its run URL and head SHA.
2. Have the VPS operator inspect the existing TEST project locally. Identify both live container IDs, health, image IDs, ports, network membership, mounts, available build capacity, backup capacity and a TEST-only maintenance window. Confirm 127.0.0.1:5174 reaches only TEST. STAGING's prod-data and prod-uploads are production-sensitive. Use Docker metadata to compare ownership and mount paths. Do not traverse or back up those trees. Check host processes, alternate Docker daemons, aliases, scheduled jobs and external upload writers. Keep TEST traffic and competing operators out for the entire maintenance window.
3. Preserve the existing untracked /opt/carserviceapp/test-compose/docker-compose.test.yml and the TEST worktree. After the approved storage migration, the script reads only `/etc/carservice-test-deploy/baseline/compose.json` to compare its digest; it never reads the legacy worktree. It builds from a separate Git mirror. Review the current TEST Compose privately and prepare a standalone root-owned copy for the frozen directory below. If the untracked file is an overlay, review its base and merge the necessary TEST settings into the standalone copy offline. It must be self-contained, use absolute TEST storage binds, the TEST workshop network, the two expected service names, health checks supplied by the images, and the hardened backend environment. For each run the script adds a private image-only Compose override with unique TEST tags. Use the supplied standalone JSON-format Compose template (JSON is valid YAML), without build or file-loading declarations; the release uses separate builds and Compose runs with --no-build and --pull never. Review any mismatch as a deliberate operator change before enabling. Never substitute the staging Compose file. Preserve a private baseline copy of the currently working TEST configuration and environment for recovery.
4. Install Python 3.12+, Git, GitHub CLI, Docker and Compose v2 with config --format json and up --wait support. Review the effective configuration locally in private memory or a mode-0600 file. Never print interpolated configuration. Reject include, extends, env_file, file interpolation, proxies, extra contexts or paths that would read unrelated server files. Check root filesystem layout: this implementation refuses submounts, bind aliases or separate parent mounts covering TEST storage. A different legitimate layout needs a reviewed isolation mapping. Verify source/data ownership cannot be changed by the SSH identity. Reserve disk, CPU and memory headroom for two builds on the shared VPS; the backup verifier defaults to a 1 GiB upload bound and needs private /var/tmp scratch space.
5. As an operator, install the reviewed scripts/test_deploy.py as /usr/local/sbin/carservice-test-deploy (root:root 0755) and scripts/ops_storage.py beside it as /usr/local/sbin/ops_storage.py (root:root 0644). Install the forced command ops/test-deploy/ssh-gate at /usr/local/sbin/carservice-test-ssh-gate (root:root 0755). Do not execute deployment tools from a developer checkout. Keep all ancestors root-owned and non-writable by group/other. Provision /etc/carservice-test-deploy root-owned 0711 and /var/lib/carservice-test-deploy and its home directory root-owned 0700. Use root-private /etc/carservice-test-deploy/environment (0600 file) and /srv/carserviceapp-test/backups (0700 directory), with /srv/carserviceapp-test root-owned 0700. Existing app-owned TEST data/uploads need their normal service permissions. Validate before changing any ownership.
6. Install the approved standalone Compose copy in /etc/carservice-test-deploy/docker-compose.test.yml. Create a root-private bare mirror at /var/lib/carservice-test-deploy/source.git (directory mode 0700), with origin exactly https://github.com/MTZBRN/CarServiceApp.git and no custom hooks or URL rewrites. Configure private-repository HTTPS access, if needed, using a dedicated read-only credential and the tool's HOME=/var/lib/carservice-test-deploy/home. Place a separate fine-grained token with repository Actions read and metadata read in /etc/carservice-test-deploy/actions-read.token (0600). Never place either credential in a URL, checkout, Docker context or Actions log.
7. For **each release**, review the exact test-deploy tip SHA, successful push CI, all migrations since the running version and the expected complete ordered list of EF migration IDs. This path admits migration history extensions and checks pre-existing business table row counts. Reject drops, data rewrites or incompatible rollback assumptions during review. As root, create /etc/carservice-test-deploy/approved.json mode 0600 using local SHA-256 digests of the root-controlled baseline/compose.json, runtime Compose and environment files. Record review time separately in UTC; use full migration names as emitted by EF, in ascending order. Example structure:

   ```json
   {
     "branch": "test-deploy",
     "revision": "<40 lowercase hexadecimal characters>",
     "storage_layout": "test-root-v1",
     "compose_sha256": "<digest of root-controlled baseline/compose.json>",
     "frozen_compose_sha256": "<digest of the reviewed standalone runtime copy>",
     "env_sha256": "<64 hex characters>",
     "migrations": ["<first actual migration ID>", "<each subsequent actual ID through the target>"]
   }
   ```

8. **Stage A.** Keep remote credentials unprovisioned. Rehearse on a disposable Linux host with a synthetic TEST-shaped installation first. Verify success and interruption after backup and during backend startup; inspect the journal, both image IDs and an isolated restored pair. Rehearse returning to the old image pair and database. On the disposable rehearsal host, invoke the installed command locally with `printf '%s\n' "$reviewed_sha" | sudo /usr/local/sbin/carservice-test-deploy`. No automatic deployment occurs on push. Archive the rehearsal journal and recovery evidence privately. Actual TEST releases go through the environment-approved Stage B dispatcher.
9. **Stage B.** Configure a GitHub environment named isolated-test. Allow deployments from the protected **test-deploy branch only**, disallow tags and bypass, use the single-maintainer approval policy below (self-review allowed where required reviewers are supported). Confirm the repository plan enforces those controls before adding secrets. Set environment variable TEST_SSH_HOST to the fixed VPS hostname (standard SSH port). Environment secrets TEST_DEPLOY_KEY and TEST_KNOWN_HOSTS hold only the dedicated private key and the host-key line verified through an independent operator channel. Never discover a host key during the deploy. The Actions authorization job uses its read-only repository token (contents and actions); the SSH job has no repository-token permissions, checkout or PR artifacts.
10. Create a dedicated SSH account carservice-test-ci, without Docker or other administrative group memberships, password login or additional credentials. Use an sshd Match rule disabling forwarding, tty, user RC, user environment and password authentication, with a root-managed AuthorizedKeysFile and a fixed ForceCommand /usr/local/sbin/carservice-test-ssh-gate. Use a root-controlled authorized_keys entry of the form `restrict,command="/usr/local/sbin/carservice-test-ssh-gate" ssh-ed25519 ...`. Prevent account-writable shell startup files or home/configuration from bypassing the gate. Use visudo to install only the **no arguments** rule below. Keep sudo env_reset, no SETENV, and no broad interpreter, shell, git, systemctl or docker grant.

    ```sudoers
    carservice-test-ci ALL=(root) NOPASSWD: /usr/local/sbin/carservice-test-deploy ""
    ```

11. Verify denial of shell commands, paths, invalid SHAs, direct Docker access, wrong branches, failed CI and unapproved revisions. Only then create the root-owned /etc/carservice-test-deploy/actions-enabled marker and set the **repository variable** TEST_DEPLOY_ENABLED=true. Dispatch from test-deploy, supply the approved SHA, and approve the environment request. Disabling the variable and removing the marker stops new normal dispatches. Revoke the key/sudo rule and remove the SHA approval for credential revocation.

## Release order and status

GitHub queues deployments in one concurrency group. The host takes a nonblocking flock shared by local and remote invocations; an unfinished journal blocks another run. The SSH gate accepts only the literal command `deploy-test test-deploy <sha>` and forwards only the validated SHA to the installed helper. The host fetches the fixed test-deploy ref, requires exact tip equality, checks commit type, root approval and successful push CI. It repeats admission after building and before stopping services. Both images are built before downtime from the two Git subtrees at that SHA. Unique TEST tags, revision labels and image IDs identify the pair.

The host checks the live project, network owner, other containers' mounts/network membership, exact bind sources and destinations, loopback publishing, effective storage configuration, baseline health and SPA/API routing. It retains rollback tags and stops only the verified TEST IDs (frontend first). After verifying both are stopped, it checks storage layout, migration history, and takes the existing SQLite online-backup plus upload archive. It checks hashes and rehearses a full restore into a fresh private scratch directory. Backend startup applies EF migrations. Before starting the frontend, the tool checks the backend image, complete migration history, database integrity, foreign keys and existing business counts. Final checks verify both running IDs/health through Compose, the SPA response and a 401 from the protected API via port 5174.

The private run journal is /var/lib/carservice-test-deploy/<run-id>.json. It records the SHA, stages, previous container/image IDs and rollback tags, new image IDs, previous migration history and backup path. The runner receives only status, run ID and revision. Build and Compose stderr is suppressed because it may include secrets. No data, logs, env files, tokens or backup manifests are uploaded to GitHub. Keep the TEST listener in maintenance until the operator confirms success. A native printer, authenticated test-user workflow and any public edge route are separate acceptance checks.

## TEST-only failure and rollback

1. Keep traffic disabled. Preserve the journal, backup, newer database, uploads and both image pairs. Read the in-progress marker to identify the interrupted run. Determine actual container IDs, states, mounts and migration history; a process can die between a command and its next checkpoint. Do not assume a timed-out SSH job stopped the host process. Confirm the host lock is free before recovery.
2. Before any new backend started, the existing database and image pair should still agree. Verify that history and container IDs match the baseline. If the old containers were stopped, start those exact IDs, backend first, wait for health, then frontend. Re-run the protected API and SPA checks. If identities or schema differ, use the next procedure.
3. Once a new backend may have started, keep the frontend offline. Never run EF Down or start an older image against an unverified newer schema. Revalidate the source backup path under /srv/carserviceapp-test/backups against the journal, repeat the existing restore test into a new private scratch directory, and compare the restored history with before_migrations. If any writes resumed, preserve and reconcile them before any switch.
4. For incompatible or uncertain schema, restore the verified database **and uploads together** into fresh, separate TEST recovery directories. Match the original service UID/GID and modes. Give the recovery Compose copy only those new TEST binds, the previous TEST environment, and the two journaled rollback image tags. Verify the tag-to-image-ID mapping, effective mounts, TEST project/network and loopback port. With both TEST services stopped, have the operator recreate just those services, backend first, with --no-build --pull never. Keep the failed data directories untouched. Repeat integrity/foreign-key checks, expected history, health, API/SPA and authenticated TEST smoke checks before reopening traffic. A temporary recovery bind layout intentionally fails the next automated preflight until the operator reconciles the canonical TEST layout.
5. An image-only rollback is eligible only after proving the existing schema **and data** compatible with both previous images. Record the decision and verification. Do not downgrade migrations, prune images/volumes, run compose down -v, sync over data, or operate the staging backup service. Keep the immutable backup and incident evidence. A local operator clears the in-progress marker only after resolving the failure, recording the outcome and verifying a healthy baseline.


## Phase 6D bootstrap and single-maintainer policy

This is a prepared configuration, not a report of VPS installation. No server data was
read and no deployment was activated. See [bootstrap steps](BOOTSTRAP.md),
[Linux rehearsal](REHEARSAL.md), and [validation evidence](VALIDATION.md).

Phase 6E adds a separate manual `rehearse-test-deploy.yml` workflow for Stage A.
It uses fictional images/data and local admission fixtures inside a disposable,
network-isolated Docker daemon. It needs no TEST/PROD credentials and does not
activate or invoke the real deployment workflow. Its recovery step requires the
operator's explicit `approve_fixture_recovery` dispatch choice. It validates
deployment orchestration; real application/EF and GitHub/SSH admission still need
their separate checks before activation. Follow REHEARSAL.md rather than
provisioning VPS credentials for this disposable rehearsal.

Configure `isolated-test` with a selected **branch** rule exactly `test-deploy` (no
wildcard/tag rule). Where required reviewers are supported, select the maintainer,
leave **Prevent self-review unchecked**, and disable administrator bypass. The same
person dispatches and approves; this is deliberate single-person accountability,
not independent approval. The separate root-owned `approved.json` still binds the
exact SHA, both Compose hashes, environment hash and complete migration inventory.

Private repositories on plans without required environment reviewers may instead
use manual dispatch plus that mandatory server approval. Record this limitation in
the release PR; keep the branch-only environment restriction and environment secrets.
If the plan cannot enforce environment branch restrictions or protected release CI,
activation remains blocked until the plan/visibility supports them. Never move SSH
secrets to repository scope as a workaround. No GitHub settings were changed here.
[GitHub environment capabilities](https://docs.github.com/en/actions/reference/workflows-and-actions/deployments-and-environments)
and [reviewer configuration](https://docs.github.com/en/actions/how-tos/deploy/configure-and-manage-deployments/manage-environments).

The workflow's repository/ref/protection/enablement guards and exact successful
`worksheet-ci.yml` push-SHA check are unchanged. The host repeats tip/CI/approval
checks before stopping containers. The single-maintainer setting affects only human
review rules, not backup, restore verification, migration admission or rollback.
