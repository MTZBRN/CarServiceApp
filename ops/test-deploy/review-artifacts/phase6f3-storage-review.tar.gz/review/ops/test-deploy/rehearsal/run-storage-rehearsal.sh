#!/usr/bin/env bash
set -euo pipefail
[[ $# == 2 && $1 == --approve-disposable-host && $2 == --approve-fictional-recovery ]] || {
  echo 'STOP: dedicated disposable Linux host and fictional recovery approval required'; exit 1;
}
[[ $(uname -s) == Linux ]]
[[ -z ${DOCKER_HOST:-}${DOCKER_CONTEXT:-}${SSH_AUTH_SOCK:-}${GH_TOKEN:-}${GITHUB_TOKEN:-} ]]
[[ $(docker context show) == default ]]
[[ $(docker context inspect default --format '{{.Endpoints.docker.Host}}') == unix:///var/run/docker.sock ]]
[[ -z $(docker ps -aq) ]] || { echo 'STOP: host already has containers'; exit 1; }
cd -- "$(dirname -- "$0")"
sha256sum --check SHA256SUMS
[[ ! -e base.tar && ! -e evidence ]] || { echo 'STOP: use a fresh extracted package'; exit 1; }
mkdir -m 700 evidence
tag="phase6f3-harness-$$"
box=''
cleanup() {
  if [[ -n $box ]] && docker container inspect "$box" >/dev/null 2>&1; then
    [[ $(docker inspect -f '{{index .Config.Labels "phase6f3"}}' "$box") == disposable ]]
    docker cp "$box:/evidence" "evidence/$box" >/dev/null 2>&1 || true
    docker rm -f "$box" >/dev/null
  fi
}
trap cleanup EXIT
docker pull python:3.12-slim-bookworm
docker save -o base.tar python:3.12-slim-bookworm
docker build -t "$tag" .
docker version --format '{{json .}}' > evidence/docker-version.json
docker image inspect --format '{{.Id}} {{json .RepoDigests}}' python:3.12-slim-bookworm "$tag" > evidence/image-identities.txt
for scenario in success before-cutover interrupted-cutover failed-startup; do
  box="phase6f3-$scenario-$$"
  docker run -d --name "$box" --label phase6f3=disposable \
    --privileged --network none --cgroupns private "$tag" >/dev/null
  [[ $(docker inspect -f '{{json .Mounts}}' "$box") == '[]' ]]
  [[ $(docker inspect -f '{{.HostConfig.NetworkMode}}' "$box") == none ]]
  [[ $(docker inspect -f '{{.HostConfig.CgroupnsMode}}' "$box") == private ]]
  ready=false
  for attempt in $(seq 1 90); do
    if docker exec "$box" test -e /run/phase6e-ready; then ready=true; break; fi
    sleep 1
  done
  [[ $ready == true ]]
  docker exec -w /review "$box" python3 -m unittest discover -s scripts/tests -p test_test_deploy.py
  docker exec -w /review "$box" python3 -m unittest discover -s scripts/tests -p test_ops_storage.py
  docker exec "$box" python3 /review/ops/test-deploy/rehearsal/storage_cutover.py "$scenario" --approve-fictional-recovery | tee "evidence/$scenario.jsonl"
  cleanup
  box=''
done
echo 'PASS: four disposable storage scenarios; real VPS remains unverified'
