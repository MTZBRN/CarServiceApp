"""Disposable fictional storage-cutover integration; never an operator migration tool."""
from contextlib import closing
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import sqlite3
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import harness as h
d = h.d
OLD = Path('/opt/carserviceapp')
WORK = Path('/cutover-fixture')
SCENARIOS = ('success', 'before-cutover', 'interrupted-cutover', 'failed-startup')


def dc(file, *args):
    # Native plugin only; Dockerfile.storage installs no Compose adapter.
    return h.real_run('docker', 'compose', '--project-name', d.PROJECT,
                     '--project-directory', str(d.ETC), '--env-file', str(d.ENV_FILE),
                     '-f', str(file), *args, env={'APP_IMAGE_TAG': 'baseline'}, timeout=180)


def pair_state(data, uploads):
    with closing(d.storage.readonly(data / 'app.db')) as db:
        schema = list(db.execute('SELECT MigrationId FROM __EFMigrationsHistory ORDER BY MigrationId'))
        logical_digest = hashlib.sha256('\n'.join(db.iterdump()).encode()).hexdigest()
    return d.storage.database_info(data / 'app.db'), schema, logical_digest, d.storage.inventory(uploads)


def containers_state():
    result = {}
    for cid in h.real_run('docker', 'ps', '-aq', '--filter', 'label=com.docker.compose.project='+d.PROJECT).splitlines():
        value = json.loads(h.real_run('docker', 'inspect', '-f',
            '[{{json .Id}},{{json .Image}},{{json .State.Status}},{{json .State.Health.Status}},{{json .Mounts}},{{json (index .Config.Labels "com.docker.compose.service")}}]', cid))
        h.require(value[5] in d.SERVICES and value[5] not in result, 'unexpected fixture service')
        result[value[5]] = value
    h.require(set(result) == set(d.SERVICES), 'fixture service missing')
    return result


def verify_services(expected_images, data):
    state = containers_state()
    for name, row in state.items():
        h.require(row[1] == expected_images[name] and row[2:4] == ['running', 'healthy'], 'image or health mismatch')
        binds = {(m['Source'], m['Destination']) for m in row[4] if m['Type'] == 'bind'}
        expected = {(str(data), '/app/data'), (str(data.parent / ('test-uploads' if data.name == 'test-data' else 'uploads')), '/app/uploads')} if name == 'backend' else set()
        h.require(binds == expected, 'cutover bind mismatch')


def journal(stage):
    temp = WORK / 'journal.tmp'
    temp.write_text(json.dumps({'stage': stage}))
    temp.replace(WORK / 'journal.json')


def worker():
    h.boundary()
    h.require((WORK / 'journal.json').read_text() == json.dumps({'stage': 'copied'}), 'interruption stage mismatch')
    dc(WORK / 'new.json', 'up', '-d', '--no-build', '--pull', 'never', '--no-deps', '--wait', 'backend')
    journal('backend-started')
    os.kill(os.getpid(), signal.SIGKILL)


def run(scenario):
    h.boundary()
    h.require(not h.real_run('docker', 'ps', '-aq'), 'fresh disposable daemon required')
    for path in (OLD, WORK, d.BASE, d.ETC):
        h.require(not os.path.lexists(path), 'fresh fixture paths required')
        path.mkdir(mode=0o700)
    (d.STATE).mkdir(mode=0o700)
    (d.STATE / 'home').mkdir(mode=0o700)
    for path in (OLD/'test-data', OLD/'test-uploads', d.BACKUPS):
        path.mkdir(mode=0o700)
    with closing(sqlite3.connect(OLD/'test-data/app.db')) as db, db:
        db.executescript("CREATE TABLE Customers(Id INTEGER PRIMARY KEY, Name TEXT); INSERT INTO Customers VALUES(1,'FICTIONAL'); CREATE TABLE __EFMigrationsHistory(MigrationId TEXT PRIMARY KEY, ProductVersion TEXT); INSERT INTO __EFMigrationsHistory VALUES('001_fixture','fixture');")
    h.write(OLD/'test-uploads/fictional.txt', 'FICTIONAL\n')
    h.own_pair(OLD/'test-data', OLD/'test-uploads')
    os.chown(OLD, 1000, 1000)
    OLD.chmod(0o750)
    h.write(d.ENV_FILE, 'JWT_KEY=FICTIONAL\nJWT_ISSUER=fixture\nJWT_AUDIENCE=fixture\nTEST_SUBNET=172.29.80.0/24\nTEST_BACKEND_IP=172.29.80.2\nTEST_FRONTEND_IP=172.29.80.3\n')
    raw = json.loads((h.REVIEW/'ops/test-deploy/docker-compose.test.yml').read_text())
    h.write(WORK/'new.json', json.dumps(raw))
    # Validate exact native normalized output. No removal of default/null keys.
    model = json.loads(dc(WORK/'new.json', 'config', '--format', 'json'))
    try:
        d.validate_model(model, 'baseline')
    except d.Refused:
        print(json.dumps({'status':'STOP', 'stage':'native-compose',
            'unexpected_service_keys': {name: sorted(set(s)-set(raw['services'][name])) for name,s in model['services'].items()}}), flush=True)
        raise
    print(json.dumps({'status':'PASS', 'stage':'native-compose', 'version':h.real_run('docker','compose','version','--short')}), flush=True)
    # Only after exact-template native validation, isolate fictional inner traffic.
    raw['networks']['workshop']['internal'] = True
    h.write(WORK/'new.json', json.dumps(raw))
    for role in d.SERVICES:
        folder = WORK/role
        folder.mkdir()
        # Same image actually accesses copied DB/uploads as its non-root user.
        prefix = '''from pathlib import Path
if Path('/role').read_text().strip() == 'backend':
    import os, sqlite3
    assert not Path('/app/data/refuse-startup').exists()
    assert os.access('/app/data', os.W_OK) and os.access('/app/uploads', os.W_OK)
    with sqlite3.connect('file:/app/data/app.db?mode=ro', uri=True) as db:
        assert db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
        assert db.execute('SELECT count(*) FROM Customers').fetchone()[0] == 1
    assert Path('/app/uploads/fictional.txt').read_text() == 'FICTIONAL\\n'
'''
        h.write(folder/'fixture.py', prefix + (Path(__file__).with_name('fixture.py')).read_text(), 0o644)
        h.write(folder/'Dockerfile', h.fixture_dockerfile(role, 'old'), 0o644)
        h.real_run('docker','build','--network=none','--pull=false','-t',f'{d.PROJECT}-{role}:baseline',str(folder),timeout=240)
    old = json.loads(json.dumps(raw))
    for mount in old['services']['backend']['volumes']:
        mount['source'] = str(OLD / ('test-data' if mount['target']=='/app/data' else 'test-uploads'))
    h.write(WORK/'old.json', json.dumps(old))
    # Isolated synthetic PROD sentinel: real container, volume, network and bytes.
    h.real_run('docker','network','create','--internal','fictional-prod-network')
    h.real_run('docker','volume','create','fictional-prod-volume')
    sentinel = h.real_run('docker','run','-d','--network','fictional-prod-network',
        '--label','project=fictional-prod','--mount','type=volume,source=fictional-prod-volume,target=/sentinel',
        h.BASE_IMAGE,'python','-c',"from pathlib import Path; import time; Path('/sentinel/value').write_text('FICTIONAL-PROD'); time.sleep(3600)")
    # Explicitly wait for sentinel initialization; no comparison of a missing value.
    h.real_run('docker','exec',sentinel,'python','-c',"import time; from pathlib import Path; p=Path('/sentinel/value');\nfor _ in range(100):\n if p.exists(): break\n time.sleep(.05)\nassert p.read_text()=='FICTIONAL-PROD'")
    def prod():
        return (h.real_run('docker','inspect','-f','{{.Id}} {{.Image}} {{.State.StartedAt}} {{.State.Running}} {{json .Mounts}} {{json .NetworkSettings.Networks}}',sentinel),
                h.real_run('docker','exec',sentinel,'python','-c',"import hashlib; print(hashlib.sha256(open('/sentinel/value','rb').read()).hexdigest())"))
    before_prod = prod()
    dc(WORK/'old.json','up','-d','--no-build','--pull','never','--wait')
    initial = containers_state()
    images = {name:row[1] for name,row in initial.items()}
    baseline = pair_state(OLD/'test-data', OLD/'test-uploads')
    if scenario == 'before-cutover':
        # Genuine destination collision must be refused before stopping either ID.
        d.DATA.mkdir()
        try:
            shutil.copytree(OLD/'test-data', d.DATA)
        except FileExistsError:
            pass
        else:
            raise RuntimeError('destination collision was accepted')
        h.require(containers_state() == initial, 'pre-cutover failure changed TEST')
    else:
        for name in ('frontend','backend'):
            h.real_run('docker','stop','--time','15',initial[name][0])
        h.require(all(row[2]=='exited' for row in containers_state().values()), 'writers not stopped')
        pair = d.storage.backup(OLD/'test-data/app.db', OLD/'test-uploads', d.BACKUPS, quiesced=True)
        scratch = Path('/var/tmp/carserviceapp-restore-test-storage')
        d.storage.restore_test(pair,scratch)
        shutil.copytree(scratch/'data', d.DATA)
        shutil.copytree(scratch/'uploads', d.UPLOADS)
        h.own_pair(d.DATA,d.UPLOADS)
        h.require(pair_state(d.DATA,d.UPLOADS)==baseline, 'copied pair differs')
        journal('copied')
        if scenario == 'interrupted-cutover':
            child = subprocess.run([sys.executable, __file__, 'worker'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            h.require(child.returncode == -signal.SIGKILL, 'worker was not interrupted')
            h.require(json.loads((WORK/'journal.json').read_text())['stage']=='backend-started', 'wrong interruption point')
        elif scenario == 'failed-startup':
            h.write(d.DATA/'refuse-startup','FICTIONAL FAULT')
            try:
                dc(WORK/'new.json','up','-d','--no-build','--pull','never','--no-deps','--wait','--wait-timeout','10','backend')
            except subprocess.CalledProcessError:
                pass
            else:
                raise RuntimeError('startup fault did not fail')
        else:
            dc(WORK/'new.json','up','-d','--no-build','--pull','never','--wait')
            verify_services(images,d.DATA)
            d.validate_network(model,json.loads(h.real_run('docker','network','inspect','-f','{{json .IPAM.Config}}',d.NETWORK)))
            d.containers()
        if scenario != 'success':
            # No writes accepted; only same-image old-pair recovery is permitted.
            dc(WORK/'old.json','up','-d','--no-build','--pull','never','--wait')
            verify_services(images,OLD/'test-data')
            journal('recovered')
        h.require(pair_state(d.DATA,d.UPLOADS)==baseline, 'destination pair changed')
    h.require(pair_state(OLD/'test-data',OLD/'test-uploads')==baseline,'legacy pair changed')
    h.require(prod()==before_prod,'fictional PROD changed')
    report = {'status':'PASS','scenario':scenario,'native_compose':True,'same_images':True,
              'paired_data_verified':True,'fictional_prod_unchanged':True,'real_vps_tested':False}
    h.write(Path('/evidence/storage-report.json'),json.dumps(report))
    print(json.dumps(report))


if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('scenario',choices=(*SCENARIOS,'worker'))
    p.add_argument('--approve-fictional-recovery',action='store_true')
    a=p.parse_args()
    try:
        if a.scenario=='worker': worker()
        else:
            h.require(a.approve_fictional_recovery,'explicit fictional recovery approval required')
            run(a.scenario)
    except Exception as error:
        print(json.dumps({'status':'STOP','scenario':a.scenario,'error_type':type(error).__name__}),flush=True)
        sys.exit(1)
